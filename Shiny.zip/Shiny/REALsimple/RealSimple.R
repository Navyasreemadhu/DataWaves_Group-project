#INFO 526
#Fall 2024
#REAL simple

library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage()

# Define server logic required to draw a histogram
server <- function(input, output) {}


# Run the application
shinyApp(ui = ui, server = server)

