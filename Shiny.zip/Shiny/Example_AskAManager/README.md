`survey.csv`: https://github.com/rfordatascience/tidytuesday/tree/master/data/2021/2021-05-18
