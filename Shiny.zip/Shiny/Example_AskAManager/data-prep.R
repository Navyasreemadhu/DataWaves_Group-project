# Load packages –---------------------------------------------------------------

library(tidyverse)
library(countrycode)

#You may need to install.packages("countrycode")

# Load data --------------------------------------------------------------------

manager_survey_raw <- read_csv(
  "Example_AskAManager/survey.csv",
  na = c("", "NA"),
  show_col_types = FALSE
)

# Prep data --------------------------------------------------------------------

manager_survey <- manager_survey_raw |>
  filter(
    !is.na(industry),
    !is.na(highest_level_of_education_completed),
    currency == "USD"
  ) |>
  mutate(
    industry_other = fct_lump_min(industry, min = 100), #lump uncommon factor together https://forcats.tidyverse.org/reference/fct_lump.html 
    country = countrycode(country, origin = "country.name", destination = "cldr.name.en"), #https://cran.r-project.org/web/packages/countrycode/countrycode.pdf 
    highest_level_of_education_completed = fct_relevel(
      highest_level_of_education_completed,
      "High School",
      "Some college",
      "College degree",
      "Master's degree",
      "Professional degree (MD, JD, etc.)",
      "PhD"
    ),
    highest_level_of_education_completed = fct_recode(
      highest_level_of_education_completed,
      "Professional degree" = "Professional degree (MD, JD, etc.)"
    )
  )

# Write data -------------------------------------------------------------------

write_rds(manager_survey, "Example_AskAManager/manager-survey.rds")

#an RDS (R Data Serialization) files are a common format for saving R objects in 
#RStudio, and they allow you to preserve the state of an object between R 
#sessions. Saving your R object as an RDS file in R can be useful for sharing 
#your work with others, replicating your analysis, or simply storing your work 
#for later use. (source: https://blog.enterprisedna.co/how-to-save-load-an-rds-file-in-r/)
